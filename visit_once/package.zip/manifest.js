TLabs.addFeature({ 
   version: '1.0.5',
   mods: [
       {
          matches: "*", 
           path: 'visit_once.js' 
       }
   ]
});



